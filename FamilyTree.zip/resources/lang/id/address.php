<?php

return [
    'address'       => 'Alamat',
    'location_name' => 'Nama Lokasi',
    'latitude'      => 'Latitude',
    'longitude'     => 'Longitude',
];
